# TEAM OF 6 — PRESENTATION ROLE DIVISION
## MOIL Intelligence · SIH 2026 Internal Hackathon (PS SIH26-26009)

> **Slot assumption:** ~6 min pitch + demo, ~3 min Q&A. If your slot is 3 min, use the
> compression column. **Rule zero stays:** EVERY member can pitch the whole project in
> 90 seconds. Judges question whoever they make eye contact with.

---

## 1 · THE SIX ROLES

| # | Role | Owns | Slides | Demo moment (tab + click) | Time |
|---|------|------|--------|---------------------------|------|
| **M1** | **Opener — The Problem** | Hook, problem statement, why MOIL cares | 1–2 (top half) | Screen OFF, then reveal dashboard | 0:00–0:50 |
| **M2** | **Space Tech — Module A** | Satellites, prospectivity map, Balaghat pipeline | 2 (Module A block) | Reserve Map tab: heatmap → top-12 targets | 0:50–1:50 |
| **M3** | **ML Lead — Module B** | Models, forecast, honest metrics | 3 (Technical Approach) | Production Intelligence tab: 4-week forecast → driver bars | 1:50–2:55 |
| **M4** | **Product — Module C + Demo Driver** | Corrective actions, closed loop; DRIVES THE LAPTOP all through | 2 (Module C block) | Risks tab: pick 1 risk → attribution in tonnes → "mark as applied" | 2:55–3:50 |
| **M5** | **Data Honesty — Feasibility** | Real vs synthetic, risks & mitigations | 4 | Points at provenance labels on screen (no clicks) | 3:50–4:40 |
| **M6** | **Closer — Impact & Q&A Captain** | National impact, references, closing line; RUNS THE Q&A RELAY | 5–6 | Ends on Command Center tab (calm full view) | 4:40–5:30 + Q&A |

**Why M4 never presents slides but drives the laptop:** the demo must be seamless while
others talk. M4 is hands-on-keyboard for M2 and M3's segments (they say "next chart",
M4 clicks). M4's own segment is the payoff — the corrective-action click.

---

## 2 · VERBATIF HANDOFF LINES (memorize these six)

Bad handoffs kill pitch scores. Use these exact transitions:

1. **M1 → M2:** "So where would we drill first? [M2], show them the map."
2. **M2 → M3:** "That's WHERE. But MOIL's second pain is WHEN production slips — [M3]?"
3. **M3 → M4:** "We can predict the shortfall four weeks out. The real question is what to DO — [M4]?"
4. **M4 → M5:** "That's the loop: predict, explain, act. Now — how much of this is real? [M5], honestly."
5. **M5 → M6:** "Every number on screen carries its label. What does this mean for India? [M6]."
6. **M6 → close:** "One platform — where to explore, what will slip, what to fix. We are [Team Name], and this is MOIL Intelligence. Thank you."

---

## 3 · Q&A RELAY MAP (who fields what)

**M6 always repeats/rephrases the question first**, then taps the owner. If the owner
freezes >3 seconds, M6 answers from the cheat card.

| Jury asks about… | Fields it | Killer first sentence |
|---|---|---|
| Which model / why not deep learning / XGBoost | **M3** | "Logistic and ridge — deliberately interpretable at 10³–10⁴ samples; deep nets would memorize the simulation." |
| Accuracy / "your 0.61 is low" | **M3** | "0.61 is discovery-blind block-CV on real public data — most teams report the leaky 1.00; we show why that's fake." |
| Satellites seeing underground | **M2** | "They can't — and we never claim it. Prospectivity from surface indicators; geophysics needs MOIL data." |
| Data real or fake? | **M5** | "Three labels on every screen: REAL PUBLIC, SIMULATED, MODEL OUTPUT. ERA5 weather is real; ops data is labeled simulation." |
| Which database / show code | **M4** (drives) + **M3** (explains) | Open `src/lib/ml/regression.ts` — "ridge regression, gradient descent, ~80 lines, readable." |
| Business value / cost / ROI | **M6** | "38 ranked actions ≈ 1,886 t estimated recovery in the demo portfolio — the queue is the product." |
| What if MOIL gives real data? | **M5** | "Models read the database, not the simulation — retrain, rebuild nothing." |
| Scalability / other minerals | **M6** | "A new mine is a new row, not a new project — the method, not the metal." |
| Anything about the problem statement | **M1** | Back to the PS three asks: identify & map · predict · recommend. |

**Trap questions (any member, all memorize):**
- *"Is 17.9 Mt a real reserve?"* — NO. Illustrative prospectivity scenario, labeled on screen; reserves are certified by drilling, CRIRSCO language only.
- *"What's running right now?"* — The 4-tab dashboard + 7 trained-model APIs on this laptop, seeded data, deterministic.

---

## 4 · 3-MINUTE COMPRESSION (if the slot is cut)

| Keeps | Drops |
|---|---|
| M1 hook (30s) | M2 pipeline detail — one sentence: "5 real public sources, honest 0.61 AUC" |
| M2 demo of heatmap (30s) | M3 model internals — just metrics + "interpretable by choice" |
| M3 forecast + metrics (30s) | M5 collapses into M6's close ("every number labeled") |
| M4 action click (30s) | Slide 4 walked visually, not narrated |
| M6 close (30s) | |

M2, M3, M5 stay standing for Q&A coverage — they own the two hardest question zones (space tech + data honesty).

---

## 5 · REHEARSAL CHECKLIST (run twice before Sep 1)

- [ ] Full run with timer — target 5:30, hard cut at 6:00 (M6 calls time)
- [ ] Laptop drill: M4 drives blind (knows every tab without looking at notes)
- [ ] Cross-training: each member presents a NEIGHBOR's segment for 60s
- [ ] Cold-start test: `bun run dev` from a fresh clone, M4 demonstrates to the room
- [ ] Q&A relay drill with a teacher playing "hostile judge" — 10 questions, no dead air > 3s
- [ ] Print 6 copies of this sheet + the metric cheat card (AUC 0.764 demo / 0.61 real · R² 0.928 · MAPE 11.6% · 38 actions ≈ 1,886 t · FY24 MOIL 1.76 of 3.37 Mt = 52%)
- [ ] Dress code check, laptop charged, PDF deck + local dev server BOTH ready

**If a member is absent on the day:** M1 absorbs M5 (opener + honesty pair), M6 absorbs
the absent speaker's Q&A zone. Nobody rewrites slides.
