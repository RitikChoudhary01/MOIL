import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "MOIL Intelligence — Manganese Prospectivity & Production Command Center",
  description:
    "AI/ML-based manganese prospectivity mapping and production shortfall prediction system for MOIL Limited. Smart India Hackathon prototype: prospectivity mapping (demo + real Balaghat public-data pipeline), 4-week shortfall forecasting with explainable attribution, and ranked corrective actions.",
  keywords: [
    "MOIL",
    "manganese",
    "reserve estimation",
    "production shortfall prediction",
    "Smart India Hackathon",
    "explainable ML",
  ],
  authors: [{ name: "SIH Prototype Team" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
