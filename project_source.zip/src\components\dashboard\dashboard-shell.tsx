"use client";

import { useState } from "react";
import { useTheme } from "next-themes";
import { Moon, Sun, Info, Mountain, Download, FileText, FileSpreadsheet } from "lucide-react";
import { TabErrorBoundary } from "@/components/dashboard/error-boundary";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useApi } from "@/hooks/use-api";
import { TabSkeleton, ErrorCard } from "@/components/dashboard/shared";
import { OverviewTab } from "@/components/dashboard/overview-tab";
import { ReserveMapTab } from "@/components/dashboard/reserve-map-tab";
import { ProductionTab } from "@/components/dashboard/production-tab";
import { RisksTab } from "@/components/dashboard/risks-tab";
import { ModelHealthTab } from "@/components/dashboard/model-health-tab";
import { SessionBadge } from "@/components/dashboard/session-badge";
import type {
  OverviewData,
  ReserveMapData,
  ProductionData,
  RiskItem,
  RecommendationItem,
  Mine,
} from "@/lib/types";

function DownloadsMenu() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className="flex h-9 items-center gap-1.5 rounded-md border px-3 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        aria-label="Download documents and data"
      >
        <Download className="h-4 w-4" aria-hidden="true" />
        <span className="hidden sm:inline">Downloads</span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel className="text-xs">
          SIH 2026 pitch deck — full 11-slide version
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <a
            href="/MOIL_Intelligence_SIH2026_Pitch.pptx"
            download
            className="cursor-pointer"
          >
            <FileText className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">
                MOIL Intelligence Pitch — PPTX (editable)
              </p>
              <p className="text-xs text-muted-foreground">
                11 slides · problem → architecture → demo → integrity → roadmap
              </p>
            </div>
          </a>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuLabel className="text-xs">
          Jury prep — study before presenting
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <a href="/JURY_QA_BATTLEPACK.md" download className="cursor-pointer">
            <FileText className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">
                Jury Q&amp;A Battlepack — WHY · HOW · WHAT · WHEN
              </p>
              <p className="text-xs text-muted-foreground">
                20 WHY + 12 HOW + 20 trap questions · numbers table · roadmap answers
              </p>
            </div>
          </a>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href="/JURY_PREP_SPEAKING_GUIDE.md" download className="cursor-pointer">
            <FileText className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">Speaking Guide — 3-min demo flow</p>
              <p className="text-xs text-muted-foreground">
                Tab-by-tab narration cues · timing · handoffs
              </p>
            </div>
          </a>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href="/TEAM_OF_6_PRESENTATION_ROLES.md" download className="cursor-pointer">
            <FileText className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">Team of 6 — presentation roles</p>
              <p className="text-xs text-muted-foreground">Who presents what · backup answers</p>
            </div>
          </a>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href="/GOVERNMENT_IMPACT_GUIDE.md" download className="cursor-pointer">
            <FileText className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">Government impact guide</p>
              <p className="text-xs text-muted-foreground">
                NCM · Atmanirbhar Bharat · Digital India alignment
              </p>
            </div>
          </a>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuLabel className="text-xs">
          Live data exports (CSV — regenerate on click)
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <a href="/api/export?dataset=production" download className="cursor-pointer">
            <FileSpreadsheet className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">Weekly production — 10 mines</p>
              <p className="text-xs text-muted-foreground">4,000 mine-weeks · real ERA5 weather</p>
            </div>
          </a>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href="/api/export?dataset=forecasts" download className="cursor-pointer">
            <FileSpreadsheet className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">4-week forecasts + SHAP factors</p>
              <p className="text-xs text-muted-foreground">Model output · explainable attribution</p>
            </div>
          </a>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href="/api/export?dataset=recommendations" download className="cursor-pointer">
            <FileSpreadsheet className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">Corrective actions (Module C)</p>
              <p className="text-xs text-muted-foreground">Priority-ranked · impact estimates</p>
            </div>
          </a>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href="/api/export?dataset=reserves" download className="cursor-pointer">
            <FileSpreadsheet className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
            <div className="min-w-0">
              <p className="text-sm font-medium leading-tight">Reserve grid cells (demo mode)</p>
              <p className="text-xs text-muted-foreground">1,080 cells · satellite features + probability</p>
            </div>
          </a>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function ThemeToggle() {
  const { resolvedTheme, setTheme } = useTheme();
  return (
    <button
      onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
      className="flex h-9 w-9 items-center justify-center rounded-md border text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
      aria-label="Toggle light/dark theme"
    >
      <Sun className="h-4 w-4 dark:hidden" aria-hidden="true" />
      <Moon className="hidden h-4 w-4 dark:block" aria-hidden="true" />
    </button>
  );
}

export function DashboardShell() {
  const [activeTab, setActiveTab] = useState("overview");
  const overview = useApi<OverviewData>("/api/overview");
  const reserve = useApi<ReserveMapData>("/api/reserve-map");
  const production = useApi<ProductionData>("/api/production");
  const risks = useApi<{ risks: RiskItem[] }>("/api/risks");
  const recs = useApi<{ recommendations: RecommendationItem[] }>("/api/recommendations");
  const mines = useApi<{ mines: Mine[] }>("/api/mines");

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* ---------- Header ---------- */}
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-2.5 sm:px-6">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-600 text-white">
            <Mountain className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <h1 className="truncate text-base font-semibold leading-tight tracking-tight">
              MOIL Intelligence
            </h1>
            <p className="truncate text-[11px] text-muted-foreground">
              Manganese operations decision support · SIH 2026
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <TooltipProvider delayDuration={200}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge
                    variant="outline"
                    className="cursor-help gap-1.5 text-muted-foreground"
                  >
                    <Info className="h-3 w-3" aria-hidden="true" />
                    Demo data · public + synthetic
                  </Badge>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-72 text-xs leading-relaxed">
                  <p className="mb-1 font-medium">Data transparency</p>
                  <p>
                    <span className="text-green-600 dark:text-green-400">Real:</span> MOIL
                    annual-report aggregates, IMD monsoon climatology, GSI belt geology.
                  </p>
                  <p className="mt-1">
                    <span className="text-yellow-600 dark:text-yellow-400">Synthetic:</span>{" "}
                    site-level production, equipment and reserve labels modeled on realistic
                    patterns.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <DownloadsMenu />
            <SessionBadge />
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* ---------- Tabs ---------- */}
      <main id="main-content" className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-sm focus:text-primary-foreground"
        >
          Skip to content
        </a>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6 h-auto w-full justify-start gap-1 overflow-x-auto rounded-lg bg-muted/60 p-1 sm:w-auto">
            <TabsTrigger value="overview" className="px-4 py-2 text-sm">
              Overview
            </TabsTrigger>
            <TabsTrigger value="reserve" className="px-4 py-2 text-sm">
              Prospectivity Map
            </TabsTrigger>
            <TabsTrigger value="production" className="px-4 py-2 text-sm">
              Production Forecast
            </TabsTrigger>
            <TabsTrigger value="risks" className="px-4 py-2 text-sm">
              Risks &amp; Actions
            </TabsTrigger>
            <TabsTrigger value="health" className="px-4 py-2 text-sm">
              Model &amp; Data Health
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <TabErrorBoundary>
              {overview.loading ? (
                <TabSkeleton />
              ) : overview.error || !overview.data ? (
                <ErrorCard message={overview.error ?? "Failed to load"} onRetry={overview.reload} />
              ) : (
                <OverviewTab
                  data={overview.data}
                  production={production.data ?? null}
                  recs={recs.data?.recommendations ?? null}
                  onNavigate={setActiveTab}
                />
              )}
            </TabErrorBoundary>
          </TabsContent>

          <TabsContent value="reserve">
            <TabErrorBoundary>
              {reserve.loading ? (
                <TabSkeleton cards={2} />
              ) : reserve.error || !reserve.data ? (
                <ErrorCard message={reserve.error ?? "Failed to load"} onRetry={reserve.reload} />
              ) : (
                <ReserveMapTab data={reserve.data} />
              )}
            </TabErrorBoundary>
          </TabsContent>

          <TabsContent value="production">
            <TabErrorBoundary>
              {production.loading ? (
                <TabSkeleton cards={2} />
              ) : production.error || !production.data ? (
                <ErrorCard
                  message={production.error ?? "Failed to load"}
                  onRetry={production.reload}
                />
              ) : (
                <ProductionTab data={production.data} />
              )}
            </TabErrorBoundary>
          </TabsContent>

          <TabsContent value="risks">
            <TabErrorBoundary>
              {risks.loading || recs.loading || mines.loading ? (
                <TabSkeleton cards={3} />
              ) : risks.error || recs.error || mines.error || !risks.data || !recs.data || !mines.data ? (
                <ErrorCard
                  message={risks.error ?? recs.error ?? mines.error ?? "Failed to load"}
                  onRetry={() => {
                    risks.reload();
                    recs.reload();
                    mines.reload();
                  }}
                />
              ) : (
                <RisksTab
                  risks={risks.data.risks}
                  recommendations={recs.data.recommendations}
                  mines={mines.data.mines}
                  onNavigate={setActiveTab}
                />
              )}
            </TabErrorBoundary>
          </TabsContent>

          <TabsContent value="health">
            <TabErrorBoundary>
              {production.loading || reserve.loading ? (
                <TabSkeleton cards={2} />
              ) : production.error || reserve.error || !production.data || !reserve.data ? (
                <ErrorCard
                  message={production.error ?? reserve.error ?? "Failed to load"}
                  onRetry={() => {
                    production.reload();
                    reserve.reload();
                  }}
                />
              ) : (
                <ModelHealthTab
                  production={production.data}
                  reserve={reserve.data}
                />
              )}
            </TabErrorBoundary>
          </TabsContent>
        </Tabs>
      </main>

      {/* ---------- Footer (sticky bottom) ---------- */}
      <footer className="mt-auto border-t bg-muted/40">
        <div className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-3 text-[11px] text-muted-foreground sm:px-6 lg:flex-row lg:items-center lg:justify-between">
          <p className="max-w-3xl leading-relaxed">
            Weather real (ERA5 2019–2026) · site-level ops labeled synthetic · Balaghat pipeline
            real public data (MRDS · GSI · Copernicus · Sentinel-2) — full audit under Model &amp;
            Data Health. Prospectivity ≠ certified reserves.
          </p>
          <p className="leading-relaxed lg:whitespace-nowrap">
            SIH 2026 · PS SIH26-26009 · Modules A / B / C
          </p>
        </div>
      </footer>
    </div>
  );
}
