import type { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface KpiCardProps {
  title: string;
  value: React.ReactNode;
  subtext: React.ReactNode;
  icon: LucideIcon;
  /** extra classes for the big value line (e.g. text-red-600) */
  valueClassName?: string;
}

export function KpiCard({ title, value, subtext, icon: Icon, valueClassName }: KpiCardProps) {
  return (
    <Card className="gap-0 rounded-xl p-5 py-4 transition-colors duration-200 hover:border-yellow-500/40 hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
          {title}
        </p>
        <span className="rounded-md bg-yellow-500/10 p-1.5 text-yellow-700 dark:text-yellow-500">
          <Icon className="h-4 w-4" aria-hidden="true" />
        </span>
      </div>
      <div
        className={cn(
          "mt-3 text-2xl font-semibold tabular-nums tracking-tight",
          valueClassName
        )}
      >
        {value}
      </div>
      <div className="mt-1.5 text-xs leading-relaxed text-muted-foreground tabular-nums">
        {subtext}
      </div>
    </Card>
  );
}
